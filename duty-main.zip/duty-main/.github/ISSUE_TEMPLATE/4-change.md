---
name: Change request
about: Suggest any other kind of change for this project.
title: "change: "
assignees: pawamoy
---

### Is your change request related to a problem? Please describe.
<!-- A clear and concise description of what the problem is. -->

### Describe the solution you'd like
<!-- A clear and concise description of what you want to happen. -->

### Describe alternatives you've considered
<!-- A clear and concise description of any alternative solutions you've considered. -->

### Additional context
<!-- Add any other context or screenshots about the change request here. -->
